/*
 * app_main.h
 *
 *  Created on: August 29 2020
 *      Author: Kyle Rodrigues
 */

#ifndef INC_APP_MAIN_H_
#define INC_APP_MAIN_H_

void appMain(void);


#endif /* APP_APP_MAIN_H_ */
